
Automatic Driving Simulation Project (CPU-Based)

Requirements:
- Python 3.x
- opencv-python
- numpy

Install:
pip install opencv-python numpy

How to Run:
1. Put a road video named 'road.mp4' in the same folder.
2. Run:
   python automatic_driving_simulation.py

Features:
- Lane detection using Canny + Hough Transform
- Region of interest masking
- Steering center estimation
- CPU friendly
